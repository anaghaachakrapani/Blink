//
//  AppState.swift
//  Blink
//
//  Created by Anaghaa Chakrapani on 10/05/26.
//

import Combine
import Foundation
import AppKit

enum BlinkPhase {
    case idle           // Counting down to next break (1.5hr)
    case preWarning     // Last 10s before break — countdown shown in menu bar
    case breakActive    // 20s overlay visible
    case snoozing       // 15min wait after user dismissed early
    case paused         // User manually paused
}

class AppState: ObservableObject {
    // MARK: Configuration
    static let mainInterval: TimeInterval = 90 * 60     // 1.5 hours
    static let preWarningDuration: TimeInterval = 10
    static let breakDuration: TimeInterval = 20
    static let snoozeDuration: TimeInterval = 15 * 60   // 15 min
    
    // MARK: Published state
    @Published var phase: BlinkPhase = .idle
    @Published var menuBarText: String = ""
    @Published var streak: Int = 0
    @Published var breakCountdown: Int = 20
    
    // MARK: Internal
    private var phaseTimer: Timer?
    
    // MARK: Callbacks
    var onShowOverlay: (() -> Void)?
    var onHideOverlay: (() -> Void)?
    var onMenuBarUpdate: (() -> Void)?
    
    init() {
        loadStreak()
        scheduleMidnightReset()
    }
    
    // MARK: - Idle (1.5hr countdown)
    
    func startMainTimer() {
        cancelPhaseTimer()
        phase = .idle
        menuBarText = ""
        onMenuBarUpdate?()
        
        let timeUntilPreWarning = Self.mainInterval - Self.preWarningDuration
        phaseTimer = Timer.scheduledTimer(withTimeInterval: timeUntilPreWarning, repeats: false) { [weak self] _ in
            self?.startPreWarning()
        }
    }
    
    // MARK: - Pre-warning (10s)
    
    private func startPreWarning() {
        cancelPhaseTimer()
        phase = .preWarning
        var secondsLeft = Int(Self.preWarningDuration)
        menuBarText = "\(secondsLeft)"
        onMenuBarUpdate?()
        
        phaseTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard let self = self else { return }
            secondsLeft -= 1
            if secondsLeft > 0 {
                self.menuBarText = "\(secondsLeft)"
                self.onMenuBarUpdate?()
            } else {
                timer.invalidate()
                self.startBreak()
            }
        }
    }
    
    // MARK: - Break (20s)
    
    func startBreak() {
        cancelPhaseTimer()
        phase = .breakActive
        breakCountdown = Int(Self.breakDuration)
        menuBarText = ""
        onMenuBarUpdate?()
        onShowOverlay?()
        
        phaseTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard let self = self else { return }
            self.breakCountdown -= 1
            self.objectWillChange.send()
            if self.breakCountdown <= 0 {
                timer.invalidate()
                self.completeBreak()
            }
        }
    }
    
    private func completeBreak() {
        cancelPhaseTimer()
        incrementStreak()
        onHideOverlay?()
        startMainTimer()
    }
    
    func interruptBreak() {
        guard phase == .breakActive else { return }
        cancelPhaseTimer()
        onHideOverlay?()
        startSnooze()
    }
    
    // MARK: - Snooze (15min)
    
    private func startSnooze() {
        cancelPhaseTimer()
        phase = .snoozing
        menuBarText = ""
        onMenuBarUpdate?()
        
        let snoozeUntilPreWarning = Self.snoozeDuration - Self.preWarningDuration
        phaseTimer = Timer.scheduledTimer(withTimeInterval: snoozeUntilPreWarning, repeats: false) { [weak self] _ in
            self?.startPreWarning()
        }
    }
    
    // MARK: - Manual controls
    
    func takeBreakNow() {
        startBreak()
    }
    
    func togglePause() {
        if phase == .paused {
            startMainTimer()
        } else {
            cancelPhaseTimer()
            phase = .paused
            menuBarText = "⏸"
            onMenuBarUpdate?()
        }
    }
    
    // MARK: - Streak
    
    private func incrementStreak() {
        checkAndResetIfNewDay()
        streak += 1
        UserDefaults.standard.set(streak, forKey: "streak")
        UserDefaults.standard.set(Date(), forKey: "lastStreakDate")
        onMenuBarUpdate?()
    }
    
    private func loadStreak() {
        checkAndResetIfNewDay()
        streak = UserDefaults.standard.integer(forKey: "streak")
    }
    
    private func checkAndResetIfNewDay() {
        guard let lastDate = UserDefaults.standard.object(forKey: "lastStreakDate") as? Date else {
            UserDefaults.standard.set(Date(), forKey: "lastStreakDate")
            return
        }
        if !Calendar.current.isDateInToday(lastDate) {
            streak = 0
            UserDefaults.standard.set(0, forKey: "streak")
            UserDefaults.standard.set(Date(), forKey: "lastStreakDate")
        }
    }
    
    private func scheduleMidnightReset() {
        let now = Date()
        let cal = Calendar.current
        var components = cal.dateComponents([.year, .month, .day], from: now)
        components.hour = 23
        components.minute = 59
        components.second = 0
        guard var target = cal.date(from: components) else { return }
        if target < now {
            target = cal.date(byAdding: .day, value: 1, to: target) ?? target
        }
        let interval = target.timeIntervalSince(now)
        DispatchQueue.main.asyncAfter(deadline: .now() + interval) { [weak self] in
            self?.streak = 0
            UserDefaults.standard.set(0, forKey: "streak")
            self?.onMenuBarUpdate?()
            self?.scheduleMidnightReset()
        }
    }
    
    // MARK: - Helpers
    
    private func cancelPhaseTimer() {
        phaseTimer?.invalidate()
        phaseTimer = nil
    }
}

