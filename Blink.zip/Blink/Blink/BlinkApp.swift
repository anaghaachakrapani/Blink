import SwiftUI
import AppKit
import CoreText

@main
struct BlinkApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        Settings { EmptyView() }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    var menuBarManager: MenuBarManager!
    var overlayManager: OverlayWindowManager!
    let appState = AppState()
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        
        registerCustomFonts()
        debugBundle()
        
        overlayManager = OverlayWindowManager(appState: appState)
        menuBarManager = MenuBarManager(appState: appState)
        overlayManager.menuBarManager = menuBarManager  // ← wire it up
        
        appState.startMainTimer()
        
        NSWorkspace.shared.notificationCenter.addObserver(
            self,
            selector: #selector(handleWake),
            name: NSWorkspace.didWakeNotification,
            object: nil
        )
    }
    
    @objc func handleWake() {
        appState.startMainTimer()
    }
    
    private func registerCustomFonts() {
        guard let url = Bundle.main.url(forResource: "BerkshireSwash-Regular", withExtension: "ttf") else {
            print("❌ FONT FILE NOT IN BUNDLE — add BerkshireSwash-Regular.ttf to your project")
            return
        }
        var error: Unmanaged<CFError>?
        if CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error) {
            print("✅ Font registered from \(url.lastPathComponent)")
        } else {
            print("❌ Font registration failed: \(error?.takeRetainedValue().localizedDescription ?? "unknown")")
        }
    }
    
    private func debugBundle() {
        print("---- BUNDLE DIAGNOSTIC ----")
        print("Font .ttf:  \(Bundle.main.url(forResource: "BerkshireSwash-Regular", withExtension: "ttf")?.lastPathComponent ?? "❌ NOT FOUND")")
        print("Cat SVG:    \(Bundle.main.url(forResource: "menu_icon_started", withExtension: "svg")?.lastPathComponent ?? "❌ NOT FOUND")")
        
        let berkshire = NSFontManager.shared.availableFonts.filter { $0.lowercased().contains("berkshire") }
        print("Berkshire fonts available: \(berkshire)")
        print("---------------------------")
    }
}
