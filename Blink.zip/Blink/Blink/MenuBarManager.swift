import AppKit
import SwiftUI

class MenuBarManager {
    private(set) var statusItem: NSStatusItem!
    private let appState: AppState
    private var blinkTimer: Timer?
    private var isMenuBarBlinking = false
    
    init(appState: AppState) {
        self.appState = appState
        setupStatusItem()
        appState.onMenuBarUpdate = { [weak self] in
            DispatchQueue.main.async { self?.updateMenuBar() }
        }
        startMenuBarBlinkAnimation()
    }
    
    deinit { blinkTimer?.invalidate() }
    
    // For OverlayWindowManager to position the popup
    func buttonFrameOnScreen() -> NSRect? {
        guard let button = statusItem.button,
              let window = button.window else { return nil }
        return window.convertToScreen(button.frame)
    }
    
    private func setupStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        updateMenuBar()
    }
    
    private func startMenuBarBlinkAnimation() {
        // Try to blink every 2 seconds, but only actually do it during break
        blinkTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.performBlink()
        }
    }

    private func performBlink() {
        // Only blink during the 20s break
        guard appState.phase == .breakActive else { return }
        
        isMenuBarBlinking = true
        updateMenuBar()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) { [weak self] in
            self?.isMenuBarBlinking = false
            self?.updateMenuBar()
        }
    }
    
    private func updateMenuBar() {
        guard let button = statusItem.button else { return }
        let closed = (appState.phase == .breakActive) && isMenuBarBlinking
        button.image = renderIcon(closed: closed)
        button.title = appState.menuBarText.isEmpty ? "" : "  \(appState.menuBarText)"
        button.imagePosition = .imageLeft
        statusItem.menu = buildMenu()
    }
    
    private func renderIcon(closed: Bool) -> NSImage? {
        let view = MenuBarEyesIcon(closed: closed).frame(width: 38, height: 18)
        let renderer = ImageRenderer(content: view)
        renderer.scale = NSScreen.main?.backingScaleFactor ?? 2.0
        let img = renderer.nsImage
        img?.isTemplate = false
        return img
    }
    
    private func buildMenu() -> NSMenu {
        let menu = NSMenu()
        let streakItem = NSMenuItem(title: "✦ \(appState.streak) breaks today", action: nil, keyEquivalent: "")
        streakItem.isEnabled = false
        menu.addItem(streakItem)
        menu.addItem(NSMenuItem.separator())
        let breakNow = NSMenuItem(title: "Take a break now", action: #selector(takeBreakAction), keyEquivalent: "b")
        breakNow.target = self
        menu.addItem(breakNow)
        let pauseTitle = appState.phase == .paused ? "Resume" : "Pause"
        let pauseItem = NSMenuItem(title: pauseTitle, action: #selector(togglePauseAction), keyEquivalent: "p")
        pauseItem.target = self
        menu.addItem(pauseItem)
        menu.addItem(NSMenuItem.separator())
        let quit = NSMenuItem(title: "Quit Blink", action: #selector(quitAction), keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)
        return menu
    }
    
    @objc private func takeBreakAction() { appState.takeBreakNow() }
    @objc private func togglePauseAction() { appState.togglePause() }
    @objc private func quitAction() { NSApp.terminate(nil) }
}

// Keep MenuBarEyesIcon and EyeShape structs as before (don't delete them)

// MARK: - Icon views

struct MenuBarEyesIcon: View {
    let closed: Bool
    
    var body: some View {
        HStack(spacing: 4) {
            EyeShape(closed: closed)
            EyeShape(closed: closed)
        }
    }
}

struct EyeShape: View {
    let closed: Bool
    
    var body: some View {
        if closed {
            // Sleepy / closed eye — small upward curve
            Path { path in
                path.move(to: CGPoint(x: 0, y: 9))
                path.addQuadCurve(to: CGPoint(x: 16, y: 9), control: CGPoint(x: 8, y: 3))
            }
            .stroke(Color.black, style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
            .frame(width: 16, height: 16)
        } else {
            ZStack {
                // White eye base with thin black outline
                Circle()
                    .fill(Color.white)
                    .overlay(Circle().stroke(Color.black, lineWidth: 1.2))
                // Black iris
                Capsule()
                    .fill(Color.black)
                    .frame(width: 6, height: 9)
            }
            .frame(width: 16, height: 16)
        }
    }
}
