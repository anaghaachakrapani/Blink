//
//  OverlayView.swift
//  Blink
//
//  Created by Anaghaa Chakrapani on 10/05/26.
//
import SwiftUI

struct OverlayView: View {
    @EnvironmentObject var appState: AppState
    let cardCenter: CGPoint
    @State private var cardScale: CGFloat = 0.92
    @State private var cardOpacity: Double = 0
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            // Very subtle backdrop - clicks still get captured by ClickCatcherView
            Color.black.opacity(0.12).ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack(spacing: 4) {
                    Text("Today's streak")
                        .font(.custom("BerkshireSwash-Regular", size: 11))
                        .foregroundColor(.black)
                    
                    ForEach(0..<appState.streak, id: \.self) { _ in
                        Image("streak")
                            .resizable()
                            .frame(width: 18, height: 18)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 12)
                .padding(.top, 22)
                
                Text("Time to Blink!")
                    .font(.custom("BerkshireSwash-Regular", size: 22))
                    .foregroundColor(brown)
                    .padding(.top, 30)
                
                Text("\(appState.breakCountdown)")
                    .font(.custom("BerkshireSwash-Regular", size: 24))
                    .foregroundColor(brown)
                    .padding(.top, 4)
                    .contentTransition(.numericText())
                    .animation(.easeInOut(duration: 0.2), value: appState.breakCountdown)
                
                BlinkingCatView()
                    .frame(width: 155, height: 213)
                    .padding(.top, 4)
                    .allowsHitTesting(false)
                
                Spacer(minLength: 0)
            }
            .frame(width: 340, height: 312)
            .background(cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .shadow(color: .black.opacity(0.25), radius: 30, x: 0, y: 10)
            .scaleEffect(cardScale, anchor: .top)
            .opacity(cardOpacity)
            .position(cardCenter)
            .onAppear {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                    cardScale = 1.0
                    cardOpacity = 1.0
                }
            }
        }
        .allowsHitTesting(false)
    }
    
    private var brown: Color { Color(red: 0x75/255, green: 0x4D/255, blue: 0x01/255) }
    
    private var cardBackground: some View {
        RadialGradient(
            colors: [
                Color(red: 0xFE/255, green: 0xE1/255, blue: 0xA7/255),
                Color(red: 0xFE/255, green: 0xD0/255, blue: 0x75/255),
                Color(red: 0xFE/255, green: 0xBE/255, blue: 0x42/255)
            ],
            center: UnitPoint(x: 0.5, y: 0.18),
            startRadius: 8,
            endRadius: 220
        )
    }
}
