import AppKit
import SwiftUI

class OverlayWindowManager {
    private var window: NSPanel?
    private let appState: AppState
    weak var menuBarManager: MenuBarManager?  // ← wired up in AppDelegate
    
    init(appState: AppState) {
        self.appState = appState
        appState.onShowOverlay = { [weak self] in
            DispatchQueue.main.async { self?.show() }
        }
        appState.onHideOverlay = { [weak self] in
            DispatchQueue.main.async { self?.hide() }
        }
    }
    
    private func show() {
        guard window == nil, let screen = NSScreen.main else { return }
        
        let panel = NSPanel(
            contentRect: screen.frame,
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        panel.level = .screenSaver
        panel.isFloatingPanel = true
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        
        let cardCenter = computeCardCenter(in: screen)
        
        let catcher = ClickCatcherView(frame: screen.frame) { [weak self] in
            self?.appState.interruptBreak()
        }
        
        let hosting = NSHostingView(rootView: OverlayView(cardCenter: cardCenter).environmentObject(appState))
        hosting.frame = screen.frame
        hosting.autoresizingMask = [.width, .height]
        catcher.addSubview(hosting)
        
        panel.contentView = catcher
        panel.orderFront(nil)
        
        panel.alphaValue = 0
        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.25
            panel.animator().alphaValue = 1
        }
        self.window = panel
    }
    
    private func hide() {
        guard let panel = window else { return }
        NSAnimationContext.runAnimationGroup({ ctx in
            ctx.duration = 0.2
            panel.animator().alphaValue = 0
        }, completionHandler: { [weak self] in
            panel.orderOut(nil)
            self?.window = nil
        })
    }
    
    private func computeCardCenter(in screen: NSScreen) -> CGPoint {
        let cardSize = CGSize(width: 340, height: 312)
        let gap: CGFloat = 8
        
        guard let buttonFrame = menuBarManager?.buttonFrameOnScreen() else {
            // Fallback: top-right area
            return CGPoint(x: screen.frame.width - cardSize.width/2 - 30,
                           y: cardSize.height/2 + 40)
        }
        
        // Convert button bottom (screen coords, origin bottom-left)
        // to SwiftUI top-left coords (origin top-left)
        let buttonBottomInSwiftUI = screen.frame.height - buttonFrame.minY
        let cardCenterY = buttonBottomInSwiftUI + gap + cardSize.height/2
        let cardCenterX = buttonFrame.midX
        
        // Clamp so card stays on screen
        let halfW = cardSize.width / 2
        let clampedX = max(halfW + 8, min(screen.frame.width - halfW - 8, cardCenterX))
        
        return CGPoint(x: clampedX, y: cardCenterY)
    }
}

class ClickCatcherView: NSView {
    private let onClick: () -> Void
    init(frame frameRect: NSRect, onClick: @escaping () -> Void) {
        self.onClick = onClick
        super.init(frame: frameRect)
    }
    required init?(coder: NSCoder) { fatalError() }
    override func mouseDown(with event: NSEvent) { onClick() }
}

//  OverlayWindowManager.swift
//  Blink
//
//  Created by Anaghaa Chakrapani on 10/05/26.
//

